import React, { useRef } from 'react';

function Problem3() {
  
  const inputRefs = useRef(Array.from({ length: 10 }, () => React.createRef()));

  const focusEmptyInput = () => {
  
    for (let ref of inputRefs.current) {
      if (ref.current && ref.current.value === '') {
        ref.current.focus();
        break;
      }
    }
  };

  return (
    <>
      {Array.from({ length: 10 }).map((_, index) => (
        <div style={{ display: 'block' }} key={index}>
          Input {index + 1}: <input type='text' ref={inputRefs.current[index]} />
        </div>
      ))}
      <button type='button' onClick={focusEmptyInput}>
        I'm a button
      </button>
    </>
  );
}

export default Problem3;
