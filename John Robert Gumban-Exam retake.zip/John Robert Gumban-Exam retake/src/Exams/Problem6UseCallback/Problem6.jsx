import { useCallback, useEffect, useState } from 'react';
import data from './MOCK_DATA.json';

export default function Problem6() {
  const [cars, setCars] = useState(data);
  const [selected, setSelected] = useState(null);
  const [formData, setFormData] = useState({
    vin: '',
    make: '',
    model: '',
    year: '',
    color: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSave = useCallback(() => {
    setCars((prevCars) => [...prevCars, formData]);
    clearForm();
  }, [formData]);

  const handleClear = useCallback(() => {
    clearForm();
  }, []);

  const handleEdit = useCallback((car) => {
    setSelected(car);
    setFormData(car);
  }, []);

  const handleUpdate = useCallback(() => {
    setCars((prevCars) =>
      prevCars.map((car) =>
        car.vin === selected.vin ? formData : car
      )
    );
    clearForm();
  }, [formData, selected]);

  const handleDelete = useCallback((vin) => {
    setCars((prevCars) => prevCars.filter((car) => car.vin !== vin));
  }, []);

  const clearForm = () => {
    setFormData({
      vin: '',
      make: '',
      model: '',
      year: '',
      color: '',
    });
    setSelected(null);
  };

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          VIN:{' '}
          <input
            type='text'
            name='vin'
            value={formData.vin}
            onChange={handleChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Make:{' '}
          <input
            type='text'
            name='make'
            value={formData.make}
            onChange={handleChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Model:{' '}
          <input
            type='text'
            name='model'
            value={formData.model}
            onChange={handleChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Year:{' '}
          <input
            type='text'
            name='year'
            value={formData.year}
            onChange={handleChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Color:{' '}
          <input
            type='text'
            name='color'
            value={formData.color}
            onChange={handleChange}
          />
        </div>
        <button type='button' onClick={selected ? handleUpdate : handleSave}>
          {selected ? 'Update' : 'Save'}
        </button>
        <button type='button' onClick={handleClear}>
          Clear
        </button>
      </div>
      <div className='table-container'>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>VIN</th>
              <th>Make</th>
              <th>Model</th>
              <th>Year</th>
              <th>Color</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {cars.map((car) => (
              <tr key={car.vin}>
                <td>{car.vin}</td>
                <td>{car.make}</td>
                <td>{car.model}</td>
                <td>{car.year}</td>
                <td>{car.color}</td>
                <td>
                  <button type='button' onClick={() => handleEdit(car)}>
                    Edit
                  </button>
                  <button type='button' onClick={() => handleDelete(car.vin)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
