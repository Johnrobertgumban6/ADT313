import { useEffect, useRef, useState } from 'react';
import Loading from './Problem5Components/Loading';

export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true);
  const [isUserIdle, setIsUserIdle] = useState(true);
  const typingTimeoutRef = useRef(null);

  useEffect(() => {
    // Dismiss loading screen after 3 seconds
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 3000);

    return () => clearTimeout(timer); // Cleanup on unmount
  }, []);

  const handleUserActivity = () => {
    // User is typing
    setIsUserIdle(false);

    // Reset typing timeout if user keeps typing
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    // Set timeout to detect user is idle after 2 seconds of inactivity
    typingTimeoutRef.current = setTimeout(() => {
      setIsUserIdle(true);
    }, 2000);
  };

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <>
          <div style={{ display: 'block' }}>
            Input: <input type='text' onKeyDown={handleUserActivity} onKeyUp={handleUserActivity} />
            <p>User is {isUserIdle ? 'idle' : 'typing'}...</p>
          </div>
        </>
      )}
    </>
  );
}
