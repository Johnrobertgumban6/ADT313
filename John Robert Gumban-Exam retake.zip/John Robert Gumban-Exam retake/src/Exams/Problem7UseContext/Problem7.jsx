import React, { createContext, useState } from 'react';
import Lists from './Problem7Components/Lists';
import SelectedValue from './Problem7Components/Selected';
import data from './problem7_mock_data.json';

// Create Context
export const MovieContext = createContext();

export default function Problem7() {
  const [movies] = useState(data);
  const [selectedMovie, setSelectedMovie] = useState(null);

  return (
    <MovieContext.Provider value={{ movies, selectedMovie, setSelectedMovie }}>
      <div>
        <SelectedValue />
      </div>
      <div>
        <Lists />
      </div>
    </MovieContext.Provider>
  );
}
