import React, { useContext } from 'react';
import { MovieContext } from '../Problem7';

export default function SelectedValue() {
  const { selectedMovie } = useContext(MovieContext);

  return (
    <div>
      {selectedMovie ? (
        <div style={{ display: 'flex', justifyContent: 'space-around' }}>
          <div>
            <p>Title: {selectedMovie.title}</p>
            <p>Genre: {selectedMovie.genre}</p>
            <p>Release Date: {selectedMovie.release_date}</p>
            <p>Director: {selectedMovie.director}</p>
            <p>Actor 1: {selectedMovie.actor_1}</p>
          </div>
          <div>
            <p>Actor 2: {selectedMovie.actor_2}</p>
            <p>Rating: {selectedMovie.rating}</p>
            <p>Box Office: {selectedMovie.box_office}</p>
            <p>Duration (Minutes): {selectedMovie.duration_minutes}</p>
            <p>Language: {selectedMovie.language}</p>
          </div>
        </div>
      ) : (
        <p>No movie selected</p>
      )}
    </div>
  );
}
