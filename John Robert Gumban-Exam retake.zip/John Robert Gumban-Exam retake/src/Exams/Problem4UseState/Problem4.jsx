import React, { useState } from 'react';

export default function Problem4() {
  const [formData, setFormData] = useState({
    name: '',
    yearLevel: '',
    course: 'BSCS',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = () => {
    console.log('Form Data:', formData);
    alert(`Form Data: ${JSON.stringify(formData)}`);
  };

  return (
    <>
      <div style={{ display: 'block' }}>
        Name: <input type='text' name='name' onChange={handleChange} />
      </div>
      <div style={{ display: 'block' }}>
        <p>Year level:</p>
        <input
          type='radio'
          id='firstYear'
          name='yearLevel'
          value='First Year'
          onChange={handleChange}
        />
         <label htmlFor='firstYear'>First Year</label>
        <br />
        <input
          type='radio'
          id='secondYear'
          name='yearLevel'
          value='Second Year'
          onChange={handleChange}
        />
         <label htmlFor='secondYear'>Second Year</label>
        <br />
        <input
          type='radio'
          id='thirdYear'
          name='yearLevel'
          value='Third Year'
          onChange={handleChange}
        />
         <label htmlFor='thirdYear'>Third Year</label>
        <br />
        <input
          type='radio'
          id='fourthYear'
          name='yearLevel'
          value='Fourth Year'
          onChange={handleChange}
        />
         <label htmlFor='fourthYear'>Fourth Year</label>
        <br />
        <input
          type='radio'
          id='fifthYear'
          name='yearLevel'
          value='Fifth Year'
          onChange={handleChange}
        />
         <label htmlFor='fifthYear'>Fifth Year</label>
        <br />
        <input
          type='radio'
          id='irregular'
          name='yearLevel'
          value='Irregular'
          onChange={handleChange}
        />
         <label htmlFor='irregular'>Irregular</label>
        <br />
      </div>
      <div style={{ display: 'block' }}>
        Course:
        <select name='course' onChange={handleChange}>
          <option value='BSCS'>BSCS</option>
          <option value='BSIT'>BSIT</option>
          <option value='BSCpE'>BSCpE</option>
          <option value='ACT'>ACT</option>
        </select>
      </div>
      <button type='button' onClick={handleSubmit}>
        Submit
      </button>
      <div>
        <h3>Form Data:</h3>
        <pre>{JSON.stringify(formData, null, 2)}</pre>
      </div>
    </>
  );
}
